package com.capgemini.onlineBanking.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.onlineBanking.Util.RechargeDBConnection;
import com.capgemini.onlineBanking.exception.OnlineBankingException;
import com.capgemini.onlineBanking.pi.Client;

public class UserLoginDB implements IUserLogin {
	Logger logger=Logger.getRootLogger();
	public UserLoginDB()
	{
	//System.out.println("hello");
	PropertyConfigurator.configure("resources//log4j.properties");
	}

	@Override
	public String LoginValidation(String userName, String pwd) {
		String password=null;
		String result = "false";
		long accountno;
		String sb=new String();
		try{
		Class.forName("oracle.jdbc.driver.OracleDriver");  
		  
		//step2 create  the connection object  
		Connection con=RechargeDBConnection.getConnection();//("jdbc:oracle:thin:@localhost:1521:xe","sharma","admin");  
		  
		//step3 create the statement object  
		Statement stmt=con.createStatement();  
		  
		//step4 execute query  
		ResultSet rs=stmt.executeQuery("select password,accountno from bankusers where username='"+userName+"'"); 
		if(rs!=null){
			while(rs.next()){
				password=rs.getString(1);
				accountno=rs.getLong(2);
				//System.out.println(password);
				//System.out.println(pwd);
				if(password.equals(pwd)){
					result=String.valueOf(accountno);
					logger.info("user is valid");
					//System.out.println(result);
				}
				else{
					result="false";
					logger.info("User is invalid");
					//System.out.println(result);
				}
				//sb.append(planname+"      "+Integer.toString(amount)+"\n");
				//System.out.println(details);
				
			}
		}
		//step5 close the connection object  
		con.close();  
		  
		}catch(Exception e){ 
			logger.error("no data found exception");//msg=e.getMessage();
		}

		return result;
	}

	@Override
	public boolean getRegistered(String userName, String pwd, long mobile, long accountno, String email) throws ClassNotFoundException, SQLException, IOException {
		Class.forName("oracle.jdbc.driver.OracleDriver");   
		//step2 create  the connection object  
		Connection con=RechargeDBConnection.getConnection();//("jdbc:oracle:thin:@localhost:1521:xe","sharma","admin");  
		String s1="insert into bankusers values(?,?,?,?,?)";
		PreparedStatement s=con.prepareStatement(s1);
		//String s2="select rec_seq.nextval from dual";
		java.sql.Statement sw=con.createStatement();
		//ResultSet r1=sw.executeQuery(s2);
		//s.executeUpdate();
		s=con.prepareStatement(s1);
		//s.setInt(1,val);
		s.setString(1,userName);
		s.setString(2,pwd);
		s.setLong(3, mobile);
		s.setLong(4, accountno);
		//s.setString(4,status);
		s.setString(5,email);
		//s.setInt(6,amount);
		s.executeUpdate();
		logger.info("User registered successfully");
		
		return false;
	}

	@Override
	public String getMiniStatement(long accountno) {
		System.out.println(accountno);
		Date date;
		long account;
		StringBuffer sb=new StringBuffer();
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");  
			  
			//step2 create  the connection object  
			Connection con=RechargeDBConnection.getConnection();//("jdbc:oracle:thin:@localhost:1521:xe","sharma","admin");  
			  
			//step3 create the statement object  
			Statement stmt=con.createStatement();  
			  
			//step4 execute query  
			ResultSet rs=stmt.executeQuery("select * from userTransaction where accountno='"+accountno+"'and rownum<=5"); 
			if(rs!=null){
				while(rs.next()){
					account=rs.getLong(1);
					date = rs.getDate(2);
					//System.out.println(password);
					//System.out.println(pwd);
					//sb.append(planname+"      "+Integer.toString(amount)+"\n");
					//System.out.println(details);
					sb.append(account+"                          "+date+"\n");
					
				}
			}
			//step5 close the connection object  
			con.close();  
			  
			}catch(Exception e){ 
				logger.error("no data found exception");//msg=e.getMessage();
			}

		return sb.toString();
	}

	@Override
	public String validatePayee(long payyeAccount,long account) {
		String payeename=null;
		long accountNumber=0;
		long pAccountNumber=0;
		StringBuilder sb=new StringBuilder();
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");  
			  
			//step2 create  the connection object  
			Connection con=RechargeDBConnection.getConnection();//("jdbc:oracle:thin:@localhost:1521:xe","sharma","admin");  
			  
			//step3 create the statement object  
			Statement stmt=con.createStatement(); 
			  
			//step4 execute query  
			ResultSet rs=stmt.executeQuery("select account_id,payee_account,name from payeeTable where payee_account="+payyeAccount+" and account_id="+account+""); 
			
			if(rs!=null){
				while(rs.next()){
					accountNumber=rs.getLong(1);
					pAccountNumber=rs.getLong(2);
					payeename=rs.getString(3);
					//System.out.println("hrllo");
					sb.append(pAccountNumber+"         "+payeename);
					
				}
			}
			
			if(pAccountNumber==0){
				sb.append("false");
			}
			//step5 close the connection object  
			con.close();  
			  
		}
		catch(Exception e){
		}
		return sb.toString();
	}



}
