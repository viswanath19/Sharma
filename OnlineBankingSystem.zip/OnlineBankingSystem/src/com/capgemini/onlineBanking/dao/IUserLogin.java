package com.capgemini.onlineBanking.dao;

import java.io.IOException;
import java.sql.SQLException;

public interface IUserLogin {

	String LoginValidation(String userName, String pwd);

	boolean getRegistered(String userName, String pwd, long mobile, long accountno, String email) throws ClassNotFoundException, SQLException, IOException;

	String getMiniStatement(long accountno);

	String validatePayee(long payyeAccount,long account);

	//int fundTransfer(int amount, long payyeAccount);
	

}
