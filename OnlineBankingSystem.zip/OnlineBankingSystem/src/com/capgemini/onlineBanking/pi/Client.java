package com.capgemini.onlineBanking.pi;

import java.io.IOException;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

import com.capgemini.onlineBanking.bean.UserAccountBean;
import com.capgemini.onlineBanking.exception.OnlineBankingException;
import com.capgemini.onlineBanking.service.IUserAccount;
import com.capgemini.onlineBanking.service.UserAccount;

public class Client {

	public static Scanner scan = new Scanner(System.in);
	IUserAccount inf = new UserAccount();
	
	//Method used to Logged in
	public String Login(){
		
		String userName = null;
		String pwd = null;
		
		System.out.println("Enter User Name : ");
		userName = scan.next();
		
		System.out.println("Enter Password : ");
		pwd = scan.next();
	
		String result=inf.isValidUser(userName,pwd);
		return  result;
	}
	
	
	public static void main(String[] args) throws ClassNotFoundException, SQLException, IOException, OnlineBankingException {
		
		Client c = new Client();
		UserAccountBean user =new UserAccountBean();
		
		int choice;
		
		do{
		
			System.out.println("1. Log In");
			System.out.println("2. Register Account");
			
			System.out.println("Enter your choice(1-2) : ");
			choice = scan.nextInt();
			
			switch(choice){
				case 1:
					//Login In
					String bool = c.Login();
					if(bool!="false"){
						System.out.println("Welcome Succuessfully Logged In....");
						System.out.println("Choose your service");
						System.out.println("1.View Mini statement");
						System.out.println("2.View Detailed statement");
						System.out.println("3.Change mobile number");
						System.out.println("4.Request for cheque book");
						System.out.println("5.Fund Transfer");
						long account=Long.valueOf(bool);
						int choices=scan.nextInt();
						IUserAccount ief=new UserAccount();
						switch(choices){
						case 1://long accountno=scan.nextLong();
							String miniStatement=ief.getMiniStatement(account);
							System.out.println("Account Number                     Transaction Date");
							System.out.println("_________________________________________________________");
							System.out.println(miniStatement);
							break;
						case 5:System.out.println("Enter the amount want to transfer");
						 	   int amount=scan.nextInt();
						 	   System.out.println("Enter the payee's account number");
						 	   long payyeAccount=scan.nextLong();
						 	   String accName=ief.validatePayee(payyeAccount,account);
						 	   if(!accName.equals("false")){
						 	   System.out.println(accName);
						 	   //int transaction=ief.transferMoney(amount,payyeAccount);
						 	   }
						 	   else{
						 		   System.out.println("No Payee exist with accountno "+payyeAccount);
						 	   }
						 	   
						 	   
						
						}
						
					}
					else{
						choice = -1;
						System.out.println("Invalid UserName and Password.....");
					}
					break;
				case 2:
					boolean userdetails=true;//Register
					userdetails = c.Register();
					if(userdetails==false){
						System.out.println("Sucessfully Registered.....");
					}
					else{
						choice = -1;
						System.out.println("Invalid Registration Details...");
					}
					
					
					break;
					
				default : System.out.println("Incorrect Choice....");
			}
		}while(choice!=1 && choice!=2);
		

	}


	private boolean Register() throws ClassNotFoundException, SQLException, IOException {
		String userName = null;
		String pwd = null;
		long mobile;
		long accountno;
		String email = null;
		String validatename;
		do{
		System.out.println("Enter User Name: ");
		userName = scan.next();
		validatename=inf.validateName(userName);
		if(validatename!="true"){
			System.out.println("value should be of size 20");
		}
		}while(validatename!="true");
		
		System.out.println("Email Id : ");
		email = scan.next();
		
		System.out.println("Mobile Number :");
		mobile = scan.nextLong();
		System.out.println("Account number");
		accountno=scan.nextLong();
		
		System.out.println("Enter New Password : ");
		pwd = scan.next();
	
	
		return inf.getRegistered(userName, pwd, mobile, accountno, email);
	}


	public long getAccount(long accountno) {
		return accountno;
		
	}

}
