package com.capgemini.onlineBanking.service;

import java.io.IOException;
import java.sql.SQLException;

import com.capgemini.onlineBanking.bean.UserAccountBean;

public interface IUserAccount {
	String isValidUser(String userName, String pwd);

	boolean getRegistered(String userName, String pwd, long mobile, long accountno, String email) throws ClassNotFoundException, SQLException, IOException;

	String validateName(String userName);

	String getMiniStatement(long accountno);

	String validatePayee(long payyeAccount,long account);

	//int transferMoney(int amount, long payyeAccount);
}
