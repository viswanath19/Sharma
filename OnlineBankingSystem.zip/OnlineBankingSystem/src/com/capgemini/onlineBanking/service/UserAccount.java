package com.capgemini.onlineBanking.service;

import java.io.IOException;
import java.sql.SQLException;

import com.capgemini.onlineBanking.dao.IUserLogin;
import com.capgemini.onlineBanking.dao.UserLoginDB;
import com.capgemini.onlineBanking.exception.OnlineBankingException;

public class UserAccount implements IUserAccount{

	@Override
	public String isValidUser(String userName, String pwd) {
		
		String result;
		IUserLogin il=new UserLoginDB();
		result=il.LoginValidation(userName,pwd);
		
		return result;
	}

	@Override
	public boolean getRegistered(String userName, String pwd, long mobile, long accountno, String email) throws ClassNotFoundException, SQLException, IOException {
		boolean result;
		
		IUserLogin il=new UserLoginDB();
		result=il.getRegistered(userName,pwd,mobile,accountno,email);
		return false;
	}

	@Override
	public String validateName(String userName) {
		String msg="true";
		if(userName.length()>20){
			OnlineBankingException obe=new OnlineBankingException();
			msg=obe.SqlExceptionMsg();
		}
		else{
			msg="true";
		}
		return msg;
	}

	@Override
	public String getMiniStatement(long accountno) {
		IUserLogin il=new UserLoginDB();
		String ministatement=il.getMiniStatement(accountno);
		return ministatement;
	}

	@Override
	public String validatePayee(long payyeAccount,long account) {
		String accountName;
		IUserLogin il=new UserLoginDB();
		accountName=il.validatePayee(payyeAccount,account);
		return accountName;
	}

/*	@Override
	public int transferMoney(int amount, long payyeAccount) {
		int transaction;
		IUserLogin il=new UserLoginDB();
		transaction=il.fundTransfer(amount,payyeAccount);
		return transaction;
	}
	*/

}
