package com.capgemini.onlineBanking.exception;

import java.sql.SQLException;

public class OnlineBankingException extends Exception {
	public OnlineBankingException(){
		
	}
	public OnlineBankingException(String msg){
		super(msg);
	}
	public String SqlExceptionMsg() {
		StringBuilder sb=new StringBuilder();
		try{
			throw new SQLException("Value is too large");
			
		}
		catch(Exception e){
			sb.append(e.getMessage());
		}
		return sb.toString();
	}
	
}
