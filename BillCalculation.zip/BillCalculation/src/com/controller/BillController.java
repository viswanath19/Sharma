package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bean.BillBean;
import com.service.BillService;
import com.service.IBillService;

/**
 * Servlet implementation class BillController
 */
@WebServlet("/BillController")
public class BillController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BillController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		String operation=request.getParameter("action");
		if(operation.equals("listConsumers")){
				
				IBillService ibs=new BillService();
				List<BillBean> consumers=new ArrayList<BillBean>(25);
				consumers=ibs.listConsumers();
				request.setAttribute("consumers", consumers);
				RequestDispatcher rd=request.getRequestDispatcher("/consumers.jsp");
				rd.forward(request, response);
		}
		else if(operation.equals("getBillDetails")){
			String consumerNo=request.getParameter("consumer_id");
			//System.out.println(consumerNo);
			//out.println(consumerNo);
			IBillService ibs=new BillService();
			List<BillBean> consumerdetails=new ArrayList<BillBean>(25);
			consumerdetails=ibs.getConsumerDetails(consumerNo);
			//out.println(consumerdetails);
			request.setAttribute("consumerDetails", consumerdetails);
			RequestDispatcher rd=request.getRequestDispatcher("/ConsumerDetails.jsp");
			rd.forward(request, response);
		}
		else if(operation.equals("showBills")){
			String consumerNo=request.getParameter("consumer_no");
			//out.println(consumerNo);
			System.out.println(consumerNo);
			//out.println("hello");
			IBillService ibs=new BillService();
			List<BillBean> billDetails=new ArrayList<BillBean>(25);
			billDetails=ibs.getBillDetails(consumerNo);
			System.out.println(billDetails);
			request.setAttribute("bills", billDetails);
			RequestDispatcher rd=request.getRequestDispatcher("/ViewBills.jsp");
			rd.forward(request, response);
			}
	}

}
