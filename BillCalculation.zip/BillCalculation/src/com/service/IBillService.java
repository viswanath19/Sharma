package com.service;

import java.util.List;

import com.bean.BillBean;

public interface IBillService {

	List<BillBean> listConsumers();

	List<BillBean> getConsumerDetails(String consumerNo);
	List<BillBean> getBillDetails(String consumerNo);
	

}
