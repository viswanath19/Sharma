package com.service;

import java.util.ArrayList;
import java.util.List;

import com.bean.BillBean;
import com.dao.Billdao;
import com.dao.IBilldao;

public class BillService implements IBillService{

	@Override
	public List<BillBean> listConsumers() {
		IBilldao ibd=new Billdao();
		List<BillBean> consumers=new ArrayList<BillBean>(20);
		consumers=ibd.listConsumers();
		return consumers;
	}

	@Override
	public List<BillBean> getConsumerDetails(String consumerNo) {
		IBilldao ibd=new Billdao();
		List<BillBean> consumersdetails=new ArrayList<BillBean>(20);
		consumersdetails=ibd.getConsumerDetails(consumerNo);
		return consumersdetails;
		}

	@Override
	public List<BillBean> getBillDetails(String consumerNo) {
		IBilldao ibd=new Billdao();
		List<BillBean> billDetails=new ArrayList<BillBean>(20);
		billDetails=ibd.getBillDetails(consumerNo);
		return billDetails;
	}

}
