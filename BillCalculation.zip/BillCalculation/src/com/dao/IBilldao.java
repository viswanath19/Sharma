package com.dao;

import java.util.List;

import com.bean.BillBean;

public interface IBilldao {

	List<BillBean> listConsumers();
	List<BillBean> getConsumerDetails(String consumerNo);
	List<BillBean> getBillDetails(String consumerNo);

}
