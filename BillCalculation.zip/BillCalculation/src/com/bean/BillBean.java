package com.bean;

public class BillBean {
	private long consumer_no;
	private String consumer_name;
	private String address;
	private float units;
	private int billno;
	private String billdate;
	private float cmr;
	private float amount;
	public float getUnits() {
		return units;
	}
	public void setUnits(float units) {
		this.units = units;
	}
	public int getBillno() {
		return billno;
	}
	public void setBillno(int billno) {
		this.billno = billno;
	}
	public String getBilldate() {
		return billdate;
	}
	public void setBilldate(String billdate) {
		this.billdate = billdate;
	}
	public float getCmr() {
		return cmr;
	}
	public void setCmr(float cmr) {
		this.cmr = cmr;
	}
	public float getAmount() {
		return amount;
	}
	public void setAmount(float amount) {
		this.amount = amount;
	}
	public long getConsumer_no() {
		return consumer_no;
	}
	public void setConsumer_no(long consumer_no) {
		this.consumer_no = consumer_no;
	}
	public String getConsumer_name() {
		return consumer_name;
	}
	public void setConsumer_name(String consumer_name) {
		this.consumer_name = consumer_name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
}
